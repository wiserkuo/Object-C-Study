	
	var input = {lang : "tw" , acc_id : "" , app_id : "" , error : "" , selected : "" , selectedId : "" };
	var lang = [];
	var temp = [];
	var temp2 = [];

	getParam();

	$(document).ready(function(){

		lang = getLanguage(input.lang);
		showLanguage(lang);

		$(".option-area").delegate(".option-button" , "click" , function(){ selectProduct(this); });
		$("#iap-order").click(function(){ orderProduct(input.selectedId) });

		//var itemList = "ew0KICAicHJvZHVjdF9uYW1lIiA6ICLlj7DogqHlnJbnpLrlipsiLA0KICAicHJvZHVjdF9jb3VudCIgOiAyLA0KICAicHJvZHVjdHMiIDogWw0KICAgIHsNCiAgICAgICJsb2NhbGl6ZWRfZGVzY3JpcHRpb24iIDogIuWcluekuuWKmzHlgIvmnIjnmoTmj4/ov7DoqqrmmI4iLA0KICAgICAgInByaWNlIiA6IDMwLA0KICAgICAgImxvY2FsaXplZF90aXRsZSIgOiAiMeWAi+aciCIsDQogICAgICAicHJvZHVjdElkZW50aWZpZXIiIDogIjAyN0EyMjAwMDA0IiwNCiAgICAgICJmb3JtYXR0ZWRQcmljZSIgOiAiTlQkMzAuMDAiDQogICAgfSwNCiAgICB7DQogICAgICAibG9jYWxpemVkX2Rlc2NyaXB0aW9uIiA6ICLlnJbnpLrliptMUENC54mIKOW5tOe5synnmoTmj4/ov7DoqqrmmI4iLA0KICAgICAgInByaWNlIiA6IDkwLA0KICAgICAgImxvY2FsaXplZF90aXRsZSIgOiAiMTLlgIvmnIgiLA0KICAgICAgInByb2R1Y3RJZGVudGlmaWVyIiA6ICIwMjdBMjIwMDAwNiIsDQogICAgICAiZm9ybWF0dGVkUHJpY2UiIDogIk5UJDkwLjAwIg0KICAgIH0NCiAgXQ0KfQ==";
		//showProduct(itemList);		
	});

	function getParam(){

		temp = [];
		temp.queryString = window.location.search;
		temp.query = temp.queryString.substr("1").split("&");

		for(i = 0 ; i < temp.query.length ; i++)
		{
			temp.param = temp.query[i].substr(0 , temp.query[i].indexOf("="));
			temp.value = temp.query[i].substr(temp.query[i].indexOf("=")).replace("=" , "");
			input[temp.param] = temp.value;
		}
		//console.log(input);
	}

	function getLanguage(lang){

		switch(lang)
		{
			case "tw":
			return lang = {
					  title: "APP訂閱",
					  subscriptionTitle: "訂閱項目",
					  currencyTitle: "幣別：",
					  purchase: "訂閱",
					  contact: "客服專線：02-55894589 #1",
					  extra:[],
					  error:{
					  			e001: "請選取訂閱項目"
					  		},
					  dialogueTitle:{
					  			e001: "訂閱狀態錯誤",
					  			e002: "服務訂閱中",
					  			e003: "服務訂閱中",
					  			e004: "訂閱成功"
					  		},
					  dialogue:{
					  			e001: "請再試一次",
					  			e002: "您已訂閱中",
					  			e003: "您好，<br>您目前的服務尚未到期，<br>請於到期前一個禮拜再訂閱服務，<br>有效期限至：",
					  			e004: "您的訂閱已生效"
					  		}
				   };
			break;

			case "cn":
			return lang = {
					  title: "在线订阅",
					  subscriptionTitle: "订阅项目",
					  currencyTitle: "货币：",
					  purchase: "购买服务",
					  contact: "contact@fonestock.com",
					  extra:[],
					  error:{
					  			e001: "请选择订阅项目"
					  		},
					  dialogueTitle:{
					  			e001: "订阅状态错误",
					  			e002: "服务订阅中",
					  			e003: "服务订阅中",
					  			e004: "订阅成功"
					  		},
					  dialogue:{
					  			e001: "请再试一次",
					  			e002: "您已订阅中",
					  			e003: "您好，<br>您目前的服务尚未到期，<br>请於到期前一个礼拜再订阅服务，<br>有效期限至：",
					  			e004: "您的订阅已生效"
					  		}				  
				   };
			break;

			default:
			return lang = {
					  title: "Subscription",
					  subscriptionTitle: "Item",
					  currencyTitle: "Currency：",
					  purchase: "Subscribe",
					  contact: "contact@fonestock.com",
					  extra:[],
					  error:{
					  			e001: "Please choose an item"
					  		},
					  dialogueTitle:{
					  			e001: "Error",
					  			e002: "Subscription Status",
					  			e003: "Service Status",
					  			e004: "Subscription Status"
					  		},
					  dialogue:{
					  			e001: "Please try again",
					  			e002: "Subscribing",
					  			e003: "Please subscribe again within one week of the expiration date of your subscription. Your subscription will expire on: ",
					  			e004: "Subscription complete"
					  		}
				   };
		}
		//console.log(lang);
	}

	function showLanguage(lang){

		$("title").html(lang.title);
		$(".main-corp-title").html(lang.title);
		$(".option-project-label").html(lang.subscriptionTitle);
		$(".option-currency-name").html(lang.currencyTitle);
		$(".main-button").html(lang.purchase);
		$(".footer-info-box").html(lang.contact);

		for(i = 0 ; i < 3 ; i++)
		{
			if(lang.extra[i] != undefined)
			{
				temp.html = "<div class=\"main-declare-sub\" style=\"min-height:1em;\">" + lang.extra[i] + "</div>";
				$(".main-declare-sub-insert").append(temp.html);
			}
		}
	}

	function showProduct(origin){

		try
		{	
			temp = [];
			temp.base64decode = decodeURIComponent(escape(atob(origin)));
			temp.json = JSON.parse(temp.base64decode);
			temp.data = "" , temp.productId = "" , temp.purchaseId = "" , temp.productName = "" , temp.productPrice = "" , temp.queue;
			temp.currency = {length : "" , priceStart : "" , detectNaN : ""};

			temp.queue = temp.json.product_count;
			//console.log(temp.json);
		}
		catch(e) 
		{
			alert(e);
		}

		//框格寬度
		if(temp.queue <= 2)
		{
			temp.optionAreaLength = temp.queue * 150;
			$(".option-area").css("width" , temp.optionAreaLength);
		}

		//框格長度
		if(temp.queue >= 3)
		{
			temp.optionAreaHeight = Math.ceil(temp.queue / 3) * 3;
			$(".option-area").css("height" , temp.optionAreaHeight + "em");
		}		

		temp.currency.length = temp.json.products[0].formattedPrice.length;
		for(var i = 0 ; i < temp.currency.length ; i++ )
		{
			temp.currency.detectNaN = temp.json.products[0].formattedPrice.charAt(i);
			if(isNaN(temp.currency.detectNaN) == false)
			{
				temp.currency.priceStart = parseInt(i);
				break;
			}
		}

		for( i = 0 ; i < temp.queue ; i++)
		{
			temp.currency.length = temp.json.products[i].formattedPrice.length;
			temp.productId = temp.json.products[i].productIdentifier.replace(/\./g, "");			
			temp.purchaseId = temp.json.products[i].productIdentifier;
			temp.productName = temp.json.products[i].localized_title;
			temp.productPrice = temp.json.products[i].formattedPrice.substr(temp.currency.priceStart , temp.currency.length);			

			temp.data = temp.data + '<div class="option-button option-button-target-mid" id="' + temp.productId + '" purchase="' + temp.purchaseId + '"><div class="option-button-font-s">' + temp.productName + '</div><div class="option-button-font-l">' + temp.productPrice + '</div></div>';
		}

		//商品名稱
		$(".option-project-name").text(temp.json.product_name);

		//貨幣名稱
		$(".option-currency-unit").text(temp.json.products[0].formattedPrice.substr(0 , temp.currency.priceStart));		

		//產品列表
		$(".option-area").html(temp.data);
	}

	function selectProduct(target){

		$("#" + input.selected).removeClass("option-button-selected");
		$("#" + target.id).addClass("option-button-selected");
		
		input.selected = target.id;
		input.selectedId = $("#" + input.selected).attr("purchase");
		//console.log(input);
	}

	function orderProduct(target){

		if(target != "")
		{
			//hideNotification();
			location.replace("blank.php?forapp=1&goshopping=1&product_id=" + target);
		}
		else
		{
			showNotification(lang.error.e001);
		}
	}

	function showNotification(target){

		$(".main-notification-box").animate({ backgroundColor : "#DDD" , color : "#F00" }).ready().empty().text(target);
	}

	function hideNotification(){

		$(".main-notification-box").animate({ backgroundColor : "#F1F1F1" , color : "F1F1F1" }).ready().empty().text("");
	}	

	function injectDialogue(target){

		temp2 = [];

		switch(target)
		{
			case "subs.ok":
			temp2.title = lang.dialogueTitle.e004;
			temp2.content = lang.dialogue.e004;
			break;

			case "stat.002":
			temp2.title = lang.dialogueTitle.e002;
			temp2.content = lang.dialogue.e002;
			break;

			case "stat.003":
			temp2.title = lang.dialogueTitle.e003;
			temp2.content = lang.dialogue.e003;
			break;

			default:
			temp2.title = lang.dialogueTitle.e001;
			temp2.content = lang.dialogue.e001;
		}

		//console.log(temp2);
		return temp2;
	}	

	function showDialogue(target , date){

		temp = [];
		temp.data = "";
		temp.subTemp = injectDialogue(target);
		temp.title = temp.subTemp.title;
		temp.content = temp.subTemp.content;
		temp.uri = "Blank?close=1&forapp=1";

		if(date != undefined && target == "stat.003")
		{
			temp.content = temp.content + date			
		}

		temp.data += "<div class=\"article-dialog-box\">";
		temp.data += "<div class=\"article-dialog-title\">&nbsp;" + temp.title + "</div>";
		temp.data += "<div class=\"article-dialog-content\">" + temp.content + "</div>";
		temp.data += "<a href=\"" + temp.uri + "\"><div class=\"article-dialog-clickbox\">OK</div></a></div>";
		
		$("article").append(temp.data).fadeIn();
		//console.log(temp);
	}

	function hideDialogue(){

		$("article").empty().fadeOut();
	}	

